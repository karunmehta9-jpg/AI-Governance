# AI Governance Portfolio

> "Reading the EU AI Act is not a project. These are."

This repository contains structured projects that translate AI governance
frameworks into practical, defensible artefacts. Each project simulates work
that organisations are actively trying to do — and struggling with — right
now.

The projects draw on two primary frameworks:

- **EU AI Act** — risk-based classification, high-risk system obligations,
  conformity requirements
- **NIST AI Risk Management Framework (AI RMF)** — four core functions:
  Govern, Map, Measure, Manage

---

## Repository Structure

```
.
├── project-01-ai-system-inventory/     # Inventory & EU AI Act classification engine
├── project-02-risk-assessment/         # Structured risk assessment & governance memo
├── project-03-responsible-ai-policy/   # Policy, principles, and operating model
├── project-04-incident-response/       # AI failure scenario and response timeline
├── project-05-high-risk-documentation/ # EU AI Act conformity documentation pack
└── README.md                           # This file
```

*(Projects are added incrementally — see the table below for current
status.)*

---

## The Projects

| # | Project | Primary Framework | Key Artefact | Status |
|---|---|---|---|---|
| 1 | [AI System Inventory & Classification Engine](./project-01-ai-system-inventory) | EU AI Act · NIST AI RMF | Inventory + classification rationale | ✅ Complete |
| 2 | AI Risk Assessment & Governance Review Pack | NIST AI RMF (Map, Measure) | Risk matrix + executive memo | 🔲 Planned |
| 3 | Responsible AI Policy & Operating Model | NIST AI RMF (Govern) | Policy document + process diagram | 🔲 Planned |
| 4 | AI Incident Response & Regulatory Escalation | NIST AI RMF (Manage) · EU AI Act | Incident timeline + RCA template | 🔲 Planned |
| 5 | High-Risk AI Documentation & Conformity Pack | EU AI Act (Article 9–17) | Full conformity documentation | 🔲 Planned |

---

## How to Use This Repository

Each project folder contains:

- `README.md` — scenario context, objectives, and how the artefacts connect
  to the frameworks
- **Artefacts** — the actual governance documents (policies, assessments,
  memos, inventories)

These are designed to be read in order — each project builds conceptual
depth on the last — but they are also standalone. If you're preparing for a
specific interview or role, navigate directly to the most relevant project.

All five projects use the same fictional company — **Halcyon Financial
Services**, a mid-sized EU-regulated fintech — so that systems classified
in Project 1 are the same systems assessed in Project 2, documented in
Project 5, and so on. The portfolio is meant to be read as one connected
governance programme, not five disconnected exercises.

---

## Framework Quick Reference

### EU AI Act — Risk Tiers

| Tier | Description | Examples |
|---|---|---|
| Unacceptable | Prohibited outright | Social scoring, real-time biometric surveillance |
| High-Risk | Strict obligations | Recruitment, credit, critical infrastructure, biometric ID |
| Limited Risk | Transparency obligations | Chatbots, deepfakes |
| Minimal Risk | No specific obligations | Spam filters, AI in games |

### NIST AI RMF — Core Functions

| Function | Purpose |
|---|---|
| GOVERN | Establish accountability structures, policies, and culture |
| MAP | Identify and categorise AI risks in context |
| MEASURE | Analyse and assess AI risks quantitatively and qualitatively |
| MANAGE | Prioritise and treat risks; respond to incidents |

---

## About

Built as a working AI governance portfolio — practical artefacts
demonstrating operational AI governance capability, not just framework
familiarity. Maintained alongside AIGP (AI Governance Professional)
certification study.
